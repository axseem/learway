import"../chunks/disclose-version.Bg9kRutz.js";import{p,a}from"../chunks/runtime.DYeCD_Dl.js";import{i}from"../chunks/lifecycle.CZ_Gs6tr.js";function s(r,o){a(o,!1),i(),p()}export{s as component};
