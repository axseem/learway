import{a as t}from"../chunks/entry.1a2PQWxQ.js";export{t as start};
